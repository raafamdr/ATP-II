Arquivo zip gerado em: 13/03/2023 12:10:53 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [PONTEIROS] 02. Maior Valor