Arquivo zip gerado em: 13/03/2023 12:22:25 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [STRING] 02. Texto em Maiúsculo