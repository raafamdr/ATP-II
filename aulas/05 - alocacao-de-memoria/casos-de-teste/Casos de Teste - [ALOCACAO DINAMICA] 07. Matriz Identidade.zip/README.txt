Arquivo zip gerado em: 13/03/2023 12:29:59 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [ALOCAÇÃO DINÂMICA] 07. Matriz Identidade