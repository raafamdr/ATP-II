Arquivo zip gerado em: 01/11/2022 19:31:21 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [RECURSÃO] 02. Quantidade de Entradas